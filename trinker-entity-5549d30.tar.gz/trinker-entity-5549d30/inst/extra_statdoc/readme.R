<p><img src="https://raw.githubusercontent.com/trinker/entity/master/inst/entity_logo/r_entity.png" width="300"/><br/>
<p><a href="http://trinker.github.com/entity_dev">entity</a> is a...</p>
<p>Download the development version of entity <a href="https://github.com/trinker/entity/">here</a>
