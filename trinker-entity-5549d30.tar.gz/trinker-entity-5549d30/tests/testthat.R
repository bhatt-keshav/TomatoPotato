library("testthat")
library("entity")

test_check("entity")