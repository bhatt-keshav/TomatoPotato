context("Checking named_entity")

test_that("named_entity ...",{


})

